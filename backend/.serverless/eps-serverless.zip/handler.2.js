"use strict";

let db = require('./db');
let department = require('./models/department')(db.sequelize, db.Sequelize);

module.exports.getAll = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    const textResponseHeaders = {
        'Content-Type': 'text/plain'
    };

    const jsonResponseHeaders = {
        'Content-Type': 'application/json'
    };


    department.findAll()
        .then(function(department) {
            console.log(department);
            const response = {
                statusCode: 200,
                headers: jsonResponseHeaders,
                body: JSON.stringify(department),
            };
            callback(null, response);
        })
        .catch(error => {
            callback(null, {
                statusCode: 501,
                headers: textResponseHeaders,
                body: "Couldn't fetch the orders, Error finding from DB, Error: " + error
            });
        });
};